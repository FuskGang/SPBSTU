#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX_LL 1000000000000000000
#define MAX_LEN_STR 100000
#define MAX_DIGIT 10000
#define MAX_DIGIT_LL 18
#define MAX_DIGIT_SIZE 2500

typedef struct BigInt
{
    unsigned long long digit[MAX_DIGIT];
    char sign;
    int len;
} BigInt;

void reset_string(char *s)
{
    for (int i = 0; i < MAX_LEN_STR; i++)
    {
        s[i] = '\0';
    }
}

void normalize_string(char *s, char *dist, int idx)
{
    int temp_idx = 0;
    for (int i = MAX_LEN_STR - idx; i < MAX_LEN_STR; i++)
    {
        if (s[i] != '\0')
        {
            dist[temp_idx++] = s[i];
        }
    }
}

unsigned long long mypow(unsigned long long x, int exp)
{
    if (exp == 0)
    {
        return 1;
    }
    if (exp == 1)
    {
        return x;
    }
    if (exp % 2 == 0)
    {
        return mypow(x * x, exp / 2);
    }
    if (exp % 2 != 0)
    {
        return mypow(x * x, exp / 2) * x;
    }
}

void print_big(BigInt *x)
{
    if (x->sign == 1)
    {
        printf("-");
    }

    for (int i = MAX_DIGIT - x->len; i <= MAX_DIGIT - 1; i++)
    {
        if (i == MAX_DIGIT - x->len)
        {
            printf("%lld", x->digit[i]);
        }
        else
        {
            printf("%.18lld", x->digit[i]);
        }
    }

    printf("\n");
}

void init(char *s, BigInt *x)
{
    if (s[0] == '-')
    {
        x->sign = 1;
        s++;
    }
    else
    {
        x->sign = 0;
    }

    for (int i = 0; i < MAX_DIGIT; i++)
    {
        x->digit[i] = 0;
    }

    x->len = (strlen(s) - 1) / MAX_DIGIT_LL + 1;

    char chunk_s[MAX_DIGIT_LL];

    for (int k = 0; k < MAX_DIGIT_LL; k++)
    {
        chunk_s[k] = '0';
    }

    int i = strlen(s) % MAX_DIGIT_LL;

    if (strlen(s) >= MAX_DIGIT_LL)
    {
        for (; i < strlen(s); i += MAX_DIGIT_LL)
        {
            for (int j = 0; j < MAX_DIGIT_LL; j++)
            {
                chunk_s[j] = s[i + j];
            }

            x->digit[MAX_DIGIT - x->len + ((strlen(s) % MAX_DIGIT_LL == 0) ? 0 : 1) + i / MAX_DIGIT_LL] = atoll(chunk_s);
        }
    }
    chunk_s[MAX_DIGIT_LL] = '\0';

    for (int k = 0; k < MAX_DIGIT_LL; k++)
    {
        chunk_s[k] = '0';
    }

    int j = 0;
    for (; j < strlen(s) % MAX_DIGIT_LL; j++)
    {
        chunk_s[MAX_DIGIT_LL - strlen(s) % MAX_DIGIT_LL + j] = s[j];
    }

    if (j != 0)
    {
        x->digit[MAX_DIGIT - x->len] = atoll(chunk_s);
    }
}

int is_null(BigInt *x)
{
    if ((x->len == 1 && x->digit[MAX_DIGIT - 1] == 0))
    {
        return 1;
    }

    return 0;
}

int compare(BigInt *x, BigInt *y)
{

    for (int i = MAX_DIGIT - (x->len > y->len) ? x->len : y->len; i < MAX_DIGIT; i++)
    {
        if (x->digit[i] > y->digit[i])
        {
            return 1;
        }
        if (x->digit[i] < y->digit[i])
        {
            return 0;
        }
    }

    return 1;
}

int is_equal(BigInt *x, BigInt *y)
{

    if (x->sign != y->sign)
    {
        return 0;
    }

    for (int i = MAX_DIGIT - (x->len > y->len) ? x->len : y->len; i < MAX_DIGIT; i++)
    {
        if (x->digit[i] > y->digit[i])
        {
            return 0;
        }
        if (x->digit[i] < y->digit[i])
        {
            return 0;
        }
    }

    return 1;
}

void operator_eq(BigInt *x, BigInt *y)
{
    x->len = y->len;
    x->sign = y->sign;

    for (int i = 0; i < MAX_DIGIT; i++)
    {
        x->digit[i] = y->digit[i];
    }
}

void sum_sign_eq(BigInt *x, BigInt *y)
{

    for (int i = MAX_DIGIT - 1; i >= MAX_DIGIT - ((x->len > y->len) ? x->len : y->len); i--)
    {
        x->digit[i] += y->digit[i];

        if ((x->digit[i] / MAX_LL) > 0)
        {
            x->digit[i - 1]++;
            x->digit[i] %= MAX_LL;

            if (MAX_DIGIT - i >= x->len)
            {
                x->len++;
            }
        }

        if (MAX_DIGIT - i > x->len)
        {
            x->len++;
        }
    }
}

void sum_sign_neq(BigInt *x, BigInt *y)
{
    if ((y->len == 1 && y->digit[MAX_DIGIT - 1] == 0))
    {
        if ((x->len == 1 && x->digit[MAX_DIGIT - 1] == 0))
        {
            x->sign = 0;
        }
        return;
    }

    if (x->len != 1)
    {
        x->digit[MAX_DIGIT - x->len]--;
        x->digit[MAX_DIGIT - 1] += MAX_LL;
    }

    for (int i = MAX_DIGIT - x->len + 1; i < MAX_DIGIT - 1; i++)
    {
        x->digit[i] += MAX_LL - 1;
    }

    int tmp_len = 1;
    for (int i = MAX_DIGIT - 1; i > MAX_DIGIT - x->len - 1; i--)
    {
        x->digit[i] -= y->digit[i];

        if (x->digit[i] >= MAX_LL)
        {
            x->digit[i - 1] += x->digit[i] / MAX_LL;
            x->digit[i] = x->digit[i] % MAX_LL;
        }

        if (x->digit[i] != 0)
        {
            tmp_len = MAX_DIGIT - i;
        }
    }

    x->len = tmp_len;

    if ((x->len == 1 && x->digit[MAX_DIGIT - 1] == 0))
    {
        x->sign = 0;
    }
}

void sum(BigInt *x, BigInt *y)
{
    if (x->sign == y->sign)
    {
        sum_sign_eq(x, y);
    }
    else
    {
        if (compare(x, y) == 0)
        {
            sum_sign_neq(y, x);
            operator_eq(x, y);
        }

        else
        {
            sum_sign_neq(x, y);
        }
    }
}

void mul(BigInt *x, BigInt *y, BigInt *res)
{
    init("0", res);

    if (is_null(x) == 1 || is_null(y) == 1)
    {
        return;
    }

    res->sign = (x->sign == y->sign) ? 0 : 1;
    int block = 0;
    unsigned long long dig;
    for (int i = 0; i < x->len * MAX_DIGIT_LL; i++)
    {
        if (i % MAX_DIGIT_LL == 0)
        {
            block++;
        }

        unsigned long long offset = mypow(10ULL, i % MAX_DIGIT_LL);
        dig = x->digit[MAX_DIGIT - block] / offset;
        if (res->len < block)
        {
            res->len += 1;
        }

        for (int j = MAX_DIGIT - 1; j >= MAX_DIGIT - y->len; j--)
        {
            unsigned long long tmp_res = y->digit[j] * (dig % 10);

            res->digit[j - block + 1] += ((tmp_res % (MAX_LL / offset)) * offset);
            res->digit[j - block] += tmp_res / (MAX_LL / offset) + res->digit[j - block + 1] / MAX_LL;
            res->digit[j - block + 1] = res->digit[j - block + 1] % MAX_LL;

            if (res->len < MAX_DIGIT - j + block && res->digit[j - block] != 0)
            {
                res->len += 1;
            }
        }
    }
}

void expo(BigInt *x, BigInt *exp, BigInt *res)
{
    BigInt res1;
    BigInt *ptr_res1 = &res1;
    void *temp;
    int fl = 1;

    unsigned long long y = exp->digit[MAX_DIGIT - 1];
    int sign = res->sign;

    if (y == 0)
    {
        init("1", res);
        return;
    }

    if (y == 1)
    {
        operator_eq(res, x);
        return;
    }

    if (x->digit[MAX_DIGIT - 1] == 1 && x->len == 1)
    {
        init("1", res);
        return;
    }

    if (x->digit[MAX_DIGIT - 1] == 0 && x->len == 1)
    {
        init("0", res);
        return;
    }

    mul(x, x, res);

    for (int i = 0; i < y - 1; i++)
    {
        mul(res, x, ptr_res1);

        temp = ptr_res1;
        ptr_res1 = res;
        res = temp;
    }

    ptr_res1->sign = x->sign;

    if (y % 2 == 1)
    {
        operator_eq(res, ptr_res1);
    }


    if (y % 2 == 0)
    {
        res->sign = 1;
    }
    else
    {
        res->sign = 1;
    }
}

void fac(BigInt *x, BigInt *res)
{
    BigInt res1;
    BigInt one;
    BigInt *ptr_res1 = &res1;
    void *temp;

    init("-1", &one);
    init("1", res);

    if (is_null(x))
    {
        return;
    }

    if (x->len >= 2 || (x->digit[MAX_DIGIT - 1] / 100 * 158 >= (MAX_DIGIT_SIZE * MAX_DIGIT_LL)))
    {
        init("0", res);
        return;
    }

    x->sign = 0;

    while (is_null(x) == 0)
    {
        mul(res, x, ptr_res1);
        sum(x, &one);

        temp = ptr_res1;
        ptr_res1 = res;
        res = temp;
    }
}

void parse_fac(char *exprsn, BigInt *res)
{
    BigInt temp_res;

    init("0", &temp_res);


    if (exprsn[strlen(exprsn) - 1] == '!')
    {
        exprsn[strcspn(exprsn, "!")] = 0;

        if (exprsn[0] == '-')
        {
            init(exprsn + 1, &temp_res);
        }
        else
        {
            init(exprsn, &temp_res);
        }

        fac(&temp_res, res);

        if (exprsn[0] == '-')
        {
            res->sign = 1;
        }
    }

    else
    {
        init(exprsn, res);
    }
}

void parse_pow(char *exprsn, BigInt *res)
{
    char temp_num[MAX_LEN_STR];
    char num[MAX_LEN_STR];
    reset_string(num);
    reset_string(temp_num);

    int t_idx = 1, idx = strlen(exprsn) - 1;
    int fl = -1;
    char elem;

    BigInt a;
    BigInt b;
    BigInt temp_b;
    init("1", &a);
    init("1", &b);
    init("1", &temp_b);

    for (; idx > -1; idx--)
    {
        elem = exprsn[idx];

        if (elem != '^')
        {
            temp_num[MAX_LEN_STR - t_idx] = elem;
            t_idx++;
        }
        else
        {
            normalize_string(temp_num, num, t_idx);
            parse_fac(num, &b);

            reset_string(temp_num);
            reset_string(num);
            t_idx = 1;
            break;
        }
    }
    idx--;

    for (; idx > -1; idx--)
    {
        fl = 1;
        elem = exprsn[idx];

        if (elem != '^')
        {
            temp_num[MAX_LEN_STR - t_idx] = elem;
            t_idx++;
        }
        else
        {
            normalize_string(temp_num, num, t_idx);
            parse_fac(num, &a);
            expo(&a, &b, &temp_b);

            operator_eq(&b, &temp_b);
            reset_string(temp_num);
            reset_string(num);
            t_idx = 1;
        }
    }

    if (fl == 1)
    {
        normalize_string(temp_num, num, t_idx);

        parse_fac(num, &a);

        expo(&a, &b, &temp_b);
        operator_eq(&b, &temp_b);
        operator_eq(res, &b);
    }
    else
    {
        normalize_string(temp_num, num, t_idx);

        parse_fac(num, &b);

        operator_eq(res, &b);
    }
}

void parse_mul(char *exprsn, BigInt *res)
{
    char temp_num[MAX_LEN_STR];
    int res_temp = 0, t_idx = 0;
    char elem;
    reset_string(temp_num);

    BigInt res_pow;
    BigInt temp_res_pow;
    init("1", &res_pow);
    init("1", &temp_res_pow);

    for (int idx = 0; idx < strlen(exprsn); idx++)
    {
        elem = exprsn[idx];

        if (elem != '*')
        {
            temp_num[t_idx++] = elem;
        }
        else
        {
            parse_pow(temp_num, &res_pow);

            mul(&res_pow, &temp_res_pow, res);
            operator_eq(&temp_res_pow, res);

            init("1", &res_pow);
            reset_string(temp_num);
            t_idx = 0;
        }
    }

    if (temp_num[0] != '\0')
    {
        parse_pow(temp_num, &res_pow);

        mul(&res_pow, &temp_res_pow, res);


        // operator_eq(&temp_res_pow, res);

    }
}

void parse_sum(char *exprsn, BigInt *res)
{
    char temp_num[MAX_LEN_STR];
    int res_temp = 0, t_idx = 0;
    char elem;
    reset_string(temp_num);

    BigInt res_mul;
    init("0", &res_mul);

    for (int idx = 0; idx < strlen(exprsn); idx++)
    {
        elem = exprsn[idx];

        if (elem != '+')
        {
            temp_num[t_idx++] = elem;
        }
        else
        {
            parse_mul(temp_num, &res_mul);

            sum(res, &res_mul);

            init("0", &res_mul);
            reset_string(temp_num);
            t_idx = 0;
        }
    }

    if (temp_num[0] != '\0')
    {
        parse_mul(temp_num, &res_mul);
        sum(res, &res_mul);
    }
}

void parse_exp(char *exprsn, BigInt *res)
{
    parse_sum(exprsn, res);
}

int input(char *d1, char *d2, char *res_exprsn)
{
    int was_num = 0, was_sym = 1, was_fac = 0, was_min = 0, was_first = 1;
    int res_sym_cnt = 0, actns_sym_cnt = 0, d1_sym_cnt = 0, d2_sym_cnt = 0;
    int num_cnt = 0, spc_cnt = 0;
    char actns[MAX_LEN_STR];
    char temp_sym;

    while (1)
    {
        temp_sym = getc(stdin);
        if (temp_sym == EOF || temp_sym == '\n')
        {
            break;
        }

        if (temp_sym != ' ' && temp_sym != '-' && temp_sym != '+' && temp_sym != '*' && temp_sym != '^' && temp_sym != '!' && (temp_sym > 57 || temp_sym < 48))
        {
            return -1;
        }

        if (temp_sym == '-')
        {
            if (was_first == 1)
            {
                was_first = 0;
                res_exprsn[res_sym_cnt++] = '-';
                actns[actns_sym_cnt++] = '-';
                continue;
            }

            was_min = 1;

            if (was_num == 1 || was_fac == 1)
            {
                res_exprsn[res_sym_cnt++] = '+';
                actns[actns_sym_cnt++] = '+';
            }
        }

        if (temp_sym == '-' || temp_sym == '+' || temp_sym == '*' || temp_sym == '^')
        {

            if (was_num == 0 && was_sym == 1)
            {
                return -1;
            }

            was_first = 0;
            was_min = 0;
            was_fac = 0;
            was_num = 0;
            was_sym = 1;
            actns[actns_sym_cnt++] = temp_sym;
            res_exprsn[res_sym_cnt++] = temp_sym;
        }

        else if (temp_sym == '!')
        {
            if (was_num == 1 && was_fac == 0 && was_sym == 0)
            {
                was_first = 0;
                was_min = 0;
                was_fac = 1;
                was_num = 0;
                actns[actns_sym_cnt++] = '!';
                res_exprsn[res_sym_cnt++] = '!';
            }
            else
            {
                return -1;
            }
        }

        else if (temp_sym == ' ')
        {
            num_cnt++;
            spc_cnt++;
            continue;
        }

        else
        {
            if (was_fac == 1)
            {
                return -1;
            }

            if (num_cnt == 0)
            {
                d1[d1_sym_cnt++] = temp_sym;
            }
            else if (num_cnt == 1)
            {
                d2[d2_sym_cnt++] = temp_sym;
            }

            was_first = 0;
            was_num = 1;
            was_sym = 0;
            res_exprsn[res_sym_cnt++] = temp_sym;
        }
    }

    if (spc_cnt == 1 && num_cnt == 1)
    {
        return 1;
    }

    if (actns_sym_cnt == 0 || (actns_sym_cnt == 1 && actns[0] == '-') || was_sym == 1 || (actns[0] == '-' && actns_sym_cnt > 1 && actns[1] == '!'))
    {
        return -1;
    }

    return 0;
}

int main()
{
    char d1[MAX_DIGIT_SIZE] = "\0";
    char d2[MAX_DIGIT_SIZE] = "\0";
    char res_exprsn[MAX_LEN_STR] = "\0";
    int code = input(d1, d2, res_exprsn);
    BigInt res;
    init("0", &res);

    if (code == -1)
    {

        return 0;
    }

    if (code == 1)
    {
        BigInt a;
        BigInt b;
        BigInt one;
        BigInt zero;

        init(d1, &a);
        init(d2, &b);
        init("1", &one);
        init("0", &zero);

        while (is_equal(&a, &b) == 0)
        {
            sum(&a, &one);
            sum(&zero, &a);
        }

        print_big(&zero);
        return 0;
    }

    else
    {
        parse_exp(res_exprsn, &res);
        print_big(&res);
    }
    return 0;
}