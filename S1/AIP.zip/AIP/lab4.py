dp = [[0 for _ in range(35)] for _ in range(35) ] 
dp_s = [["" for _ in range(35)] for _ in range(35)] 
 
 
 
def ans(l, r, s): 
    if dp[l][r] != 0: 
        return dp[l][r] 
     
    if l == r: 
        dp[l][r] = 1 
        dp_s[l][r] = s[l] 
        return 1 
 
    if l == r - 1: 
        if s[l] == s[r]: 
            dp[l][r] = 2 
            dp_s[l][r] = s[l] + s[r] 
            return 2 
        else: 
            dp[l][r] = 1 
            dp_s[l][r] = s[l] 
            return 1 
 
    if s[l] != s[r]: 
        l_b = ans(l + 1, r, s) 
        r_b = ans(l, r - 1, s) 
        mx_b = max(l_b, r_b) 
         
        if mx_b == r_b: 
        # else: 
            out = dp_s[l][r - 1] 
            dp_s[l][r] = out 
        elif mx_b == l_b: 
            out = dp_s[l + 1][r] 
                 
            dp_s[l][r] = out 
         
        dp[l][r] = mx_b 
          
    else: 
        l_b = ans(l + 1, r, s) 
        c_b = ans(l + 1, r - 1, s) + 2 
        r_b = ans(l, r - 1, s) 
        mx_b = max(l_b, r_b, c_b) 
 
        if mx_b == r_b: 
            out = dp_s[l][r - 1] 
            dp_s[l][r] = out 
        elif mx_b == c_b: 
            out = s[l] + dp_s[l + 1][r - 1] + s[r] 
            dp_s[l][r] = out 
        else: 
            out = dp_s[l + 1][r]        
            dp_s[l][r] = out 
                
        dp[l][r] = mx_b 
         
    return dp[l][r] 
 
def main(): 
    s = input() 
    s = s.replace(" ", "*") 
 
 
    res = ans(0, len(s) - 1, s) 
         
    answer = dp_s[0][len(s) - 1] 
 
    print(res) 
    print(dp_s[0]) 
    print(answer) 
# ( ))) . ^ ^ ^ ( ( ) )) () ) 
# ( )))  ^ ^ ^  ))) ( 
     
if __name__ == '__main__': 
    main()
