#include <stdio.h>
#include <math.h>


int main(void) {
    int a, min_a, max_a;
    short int b, min_b, max_b;
    unsigned short int c, min_c, max_c;
    char d, min_d, max_d;
    unsigned char e, min_e, max_e;
    unsigned int f, min_f, max_f;
    unsigned long long int g, min_g, max_g, offset = 2;
    float h;
    double i;

    int byte_a = (char *)(&a + 1) - (char *)(&a);
    int byte_b = (char *)(&b + 1) - (char *)(&b);
    int byte_c = (char *)(&c + 1) - (char *)(&c);
    int byte_d = (char *)(&d + 1) - (char *)(&d);
    int byte_e = (char *)(&e + 1) - (char *)(&e);
    int byte_f = (char *)(&f + 1) - (char *)(&f);
    int byte_g = (char *)(&g + 1) - (char *)(&g);
    int byte_h = (char *)(&h + 1) - (char *)(&h);
    int byte_i = (char *)(&i + 1) - (char *)(&i);

    a = (2 << (byte_a * 8 - 2)) - 1;
    b = (2 << (byte_b * 8 - 2)) - 1;
    c = (2 << (byte_c * 8 - 2)) - 1;
    d = (2 << (byte_d * 8 - 2)) - 1;
    e = (2 << (byte_e * 8 - 2)) - 1;
    f = (2 << (byte_f * 8 - 2)) - 1;
    g = (offset << (byte_g * 8 - 2)) - 1;

    if (++a < 0) 
    {
        min_a = a;
        max_a = --a;
    }
    else {
        min_a = 0;
        max_a = (a << 1) - 1;
    }

    if (++b < 0)
    {
        min_b = b;
        max_b = --b;
    }
    else
    {
        min_b = 0;
        max_b = (b << 1) - 1;
    }

    if (++c < 0)
    {
        min_c = c;
        max_c = --c;
    }
    else
    {
        min_c = 0;
        max_c = (c << 1) - 1;
    }

    if (++d < 0)
    {
        min_d = d;
        max_d = --d;
    }
    else
    {
        min_d = 0;
        max_d = (d << 1) - 1;
    }

    if (++e < 0)
    {
        min_e = e;
        max_e = --e;
    }
    else
    {
        min_e = 0;
        max_e = (e << 1) - 1;
    }

    if (++f < 0)
    {
        min_f = f;
        max_f = --f;
    }
    else
    {
        min_f = 0;
        max_f = (f << 1) - 1;
    }

    if (++g < 0)
    {
        min_g = g;
        max_g = --g;
    }
    else
    {
        min_g = 0;
        max_g = (g << 1) - 1;
    }

    printf("int: %d, %d, %d\n", byte_a, max_a, min_a);
    printf("short int: %d, %d, %d\n", byte_b, max_b, min_b);
    printf("unsigned short int: %d, %d, %d\n", byte_c, max_c, min_c);
    printf("char: %d, %d, %d\n", byte_d, max_d, min_d);
    printf("unsigned char: %d, %d, %d\n", byte_e, max_e, min_e);
    printf("unsigned int: %d, %lld, %lld\n", byte_f, max_f, min_f);
    printf("unsigned long long int: %d, %llu, %llu\n", byte_g, max_g, min_g);
    printf("float: %d\n", byte_h);
    printf("double: %d\n", byte_i);
}