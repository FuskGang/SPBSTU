#include <stdio.h>


struct name
{
    int a;
    char b;
};


int main()
{
    
}