#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define MAX_LENGTH 35

int len(char *s)
{
    int i = -1;

    while (s[++i] != '\0')
        ;

    return i;
}

int is_palindrome(char *string, char *buf, int n)
{
    char tmp_s[MAX_LENGTH + 1] = "";
    int j = 0;

    for (int i = 0; i < n; i++)
    {
        if (buf[i] == '1')
        {
            tmp_s[j++] = string[i];
        }
    }

    tmp_s[j] = '\0';

    for (int i = 0; i < j / 2; i++)
    {
        if (tmp_s[i] != tmp_s[j - i - 1])
        {
            return 0;
        }
    }

    return j;
}

void ans(char *answer, char *string, char *s, int n, int tmp_n, int *mx)
{
    if (tmp_n == n)
    {
        int n_palin = is_palindrome(string, s, n);

        if (n_palin > *mx )
        {
            *mx = n_palin;

            for (int i = 0; i < n; i++)
            {
                answer[i] = s[i];
            }
        }

        return;
    }



    s[tmp_n] = '1';
    ans(answer, string, s, n, tmp_n + 1, mx);

    s[tmp_n] = '0';
    ans(answer, string, s, n, tmp_n + 1, mx);
}

void print_res(char *s, char *buf, int n)
{
    for (int i = 0; i < n; i++)
    {
        if (buf[i] == '1')
        {
            printf("%c", s[i]);
        }
    }

    printf("\n");
    int skip[MAX_LENGTH] = {0};
    int j = 0;
    for (int i = 0; i < n; i++)
    {
        if (buf[i] == '0')
        {
            skip[j++] = i;
        }
    }

    for (int i = 0; i < j; i++)
    {
        if (i + 1 == j)
        {
            printf("%d - %c", skip[i] + 1, s[skip[i]]);
        }
        else
        {
            printf("%d - %c, ", skip[i] + 1, s[skip[i]]);
        }
    }
}

int main()
{
    char string[MAX_LENGTH + 1] = "1q2wr3t5a3gw2plmq1";
    char ss[MAX_LENGTH + 1] = "";
    char answer[MAX_LENGTH + 1] = "";
    int mx = 0;

    int tmp_c, tmp_n = 0;

    while (tmp_c != EOF && tmp_c != '\n')
    {
        tmp_c = getchar();

        if (tmp_n == 35)
        {
            break;
        }

        if (tmp_c > 128)
        {
            return 0;
        }
        if (tmp_c == '\n' || tmp_c == EOF)
        {
            break;
        }

        string[tmp_n] = tmp_c;
        tmp_n++;

    }

    int n = len(string);

    ans(answer, string, ss, n, 0, &mx);
    print_res(string, answer, n);

    return 0;
}
