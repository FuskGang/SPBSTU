import os
import random


def main():
    data_g = generate_data()
    data = [int(i) for i in data_g]
    data.sort()
    
    print("Start\n")

    os.system('.\\lab5.exe')
    
    with open('result.txt', 'r') as f:
        data_i = [int(i) for i in f.readline().strip().split(', ')]
        data_q = [int(i) for i in f.readline().strip().split(', ')]
        data_m = [int(i) for i in f.readline().strip().split(', ')]
        
    print(data == data_i, data == data_q, data == data_m)
    
    
    os.remove("result.txt")
    input()
    os.remove("characteristics.txt")
        


def generate_data():
    data_r = [random.randint(1, 100) for _ in range(100000)]
    data_r.sort(reverse=True)
    data = [str(i) for i in data_r]
    
    with open("input.txt", "w") as f:
        f.write(", ".join(data))

    return data

if __name__ == '__main__':
    main()
