#define COUNT_BOOK_PERSON 7
#define COUNT_PERSON_INFO 2
#include <stdio.h>
#include <string.h>

int cmp_str(char *book_name, char *data)
{
    int res = 0;
    int ans = 0;
    char temp_bn[60];
    char temp_d[60];

    strcpy(temp_bn, book_name);
    strcpy(temp_d, data);

    char *token_save[3];
    char *data_save[3];

    char *token_book_name = strtok(temp_bn, " ");

    while (token_book_name)
    {
        token_save[res++] = token_book_name;
        token_book_name = strtok(NULL, " ");
    }

    char *token_data = strtok(temp_d, " ");
    res = 0;

    while (token_data)
    {
        data_save[res++] = token_data;
        token_data = strtok(NULL, " ");
    }

    for (int word_book_cnt = 0; word_book_cnt < 3; word_book_cnt++)
    {
        for (int data_cnt = 0; data_cnt < res; data_cnt++)
        {
            if (!strcmp(token_save[word_book_cnt], data_save[data_cnt]))
            {
                ans++;
                break;
            }
        }
    }

    if (ans == res)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void search(char *data)
{
    char valid_phone[20];
    int fl = 0;

    if (data[0] == '+' || data[0] == '8')
    {
        char *phone = data;

        if (strlen(phone) == 11)
        {
            sprintf(valid_phone, "(%c%c%c) %c%c%c-%c%c-%c%c", phone[1], phone[2], phone[3], phone[4], phone[5], phone[6], phone[7], phone[8], phone[9], phone[10]);
        }
        else if (strlen(phone) == 12)
        {
            sprintf(valid_phone, "(%c%c%c) %c%c%c-%c%c-%c%c", phone[2], phone[3], phone[4], phone[5], phone[6], phone[7], phone[8], phone[9], phone[10], phone[11]);
        }
    }

    char contact_book[COUNT_BOOK_PERSON][COUNT_PERSON_INFO][30] = {{"Ivanov Ivan Ivanovich\0", "+7 (981) 888-33-22\0"},
                                                                   {"Kirillov Anton Efimovich\0", "+7 (999) 888-11-00\0"},
                                                                   {"Afanasieva Olga\0", "+7 (981) 345-11-22\0"},
                                                                   {"Lermontov Mikhail Yurievich\0", "8 (900) 876-54-31\0"},
                                                                   {"Pushkin Alexander Sergeevich\0", "+7 (111) 987-65-21\0"},
                                                                   {"Fet Afanasy Afanasyevich\0", "8 (000) 234-54-34\0"},
                                                                   {"Euclid\0", "+7 (123) 456-78-99\0"}};

    for (int book_peron = 0; book_peron < COUNT_BOOK_PERSON; book_peron++)
    {
        char *name = contact_book[book_peron][0];
        char *phone = contact_book[book_peron][1];

        int region_offset = (strlen(phone) == 18) ? 3 : 2;

        if (!strcmp(phone + region_offset, valid_phone))
        {
            printf("Found, %s, %s.", name, phone);
            fl = 1;
            break;
        }

        if (cmp_str(name, data) == 1)
        {
            printf("Found, %s, %s.\n", name, phone);
            fl = 1;
            break;
        }
    }

    if (fl == 0)
    {
        printf("Not found.\n");
    }
}

int main(void)
{
    char input_data[30];
    fgets(input_data, 30, stdin);
    input_data[strcspn(input_data, "\n")] = 0;

    search(input_data);
    return 0;
}