#include <stdio.h>

int size_storage[80][80];
char str_storage[80][80][80];
int cnt;

int max(int a, int b)
{
    return (a > b) ? a : b;
}

int mystrlen(char *s)
{
    int i = 0;
    while (s[++i] != '\0')
        ;

    return i;
}

void mystrcpy(char *dest, char *src)
{
    for (int i = 0; i < mystrlen(src); i++)
    {
        dest[i] = src[i];
    }
}


void write_to_arr(int l, int r, char l_s, char *c_s, char r_s)
{
    str_storage[l][r][0] = l_s;

    int i = 0;

    for (; i < mystrlen(c_s); i++)
    {
        str_storage[l][r][i + 1] = c_s[i];
    }

    str_storage[l][r][i + 1] = r_s;
}

int ans(int l, int r, char *s)
{
    cnt++;
    if (size_storage[l][r] != 0)
    {
        return size_storage[l][r];
    }

    if (l == r)
    {
        size_storage[l][r] = 1;
        str_storage[l][r][0] = s[l];
        return 1;
    }

    if (l == r - 1)
    {
        if (s[l] == s[r])
        {
            size_storage[l][r] = 2;
            str_storage[l][r][0] = s[l];
            str_storage[l][r][1] = s[r];
            return 2;
        }
        else
        {
            size_storage[l][r] = 1;
            str_storage[l][r][0] = s[l];
            return 1;
        }
    }

    if (s[l] != s[r])
    {
        int l_b = ans(l + 1, r, s);
        int r_b = ans(l, r - 1, s);
        int mx_b = max(l_b, r_b);

        if (mx_b == r_b)
        {
            mystrcpy(str_storage[l][r], str_storage[l][r - 1]);
        }
        else
        {
            mystrcpy(str_storage[l][r], str_storage[l + 1][r]);
        }

        size_storage[l][r] = mx_b;
    }

    else
    {
        int l_b = ans(l + 1, r, s);
        int c_b = ans(l + 1, r - 1, s) + 2;
        int r_b = ans(l, r - 1, s);
        int mx_b = max(l_b, max(r_b, c_b));

        if (mx_b == r_b)
        {
            mystrcpy(str_storage[l][r], str_storage[l][r - 1]);
        }
        else if (mx_b == c_b)
        {
            write_to_arr(l, r, s[l], str_storage[l + 1][r - 1], s[r]);
        }
        else
        {
            mystrcpy(str_storage[l][r], str_storage[l + 1][r]);
        }

        size_storage[l][r] = mx_b;
    }

    return size_storage[l][r];
}
// qwertyuiiopasdfghjklzxcvbnmergerigeriognqwertyuiiopasdfghjklzxcvbnmergerigeriogn
int main()
{
    char s[80];
    cnt = 0;
    int s_cnt = 0, was_print = 0, s_out_help = 0, ans_cnt = 0;

    while (1)
    {
        char temp = getc(stdin);
        if (temp == EOF || temp == '\n')
        {
            break;
        }

        if (s_cnt == 80)
        {
            break;
        }

        s[s_cnt++] = temp;
    }

    s[s_cnt] = '\0';

    int res = ans(0, mystrlen(s) - 1, s);

    char answer[80] = "\0";

    int i = 0;
    for (; i < mystrlen(str_storage[0][mystrlen(s) - 1]); i++)
    {
        answer[i] = str_storage[0][mystrlen(s) - 1][i];
    }

    answer[i] = '\0';

    printf("%s\n", answer);
    printf("%d", cnt);
    // int n = mystrlen(answer);

    // int s_chr = 0, ans_chr = 0;

    // while (s_chr != s_cnt)
    // {
    //     if (s[s_chr] == answer[ans_chr])
    //     {
    //         s_chr++;

    //         if (ans_chr < n)
    //         {
    //             ans_chr++;
    //         }

    //         continue;
    //     }

    //     if (was_print == 0)
    //     {
    //         printf("%d - %c", s_chr + 1, s[s_chr]);
    //         was_print = 1;
    //     }
    //     else
    //     {
    //         printf(", %d - %c", s_chr + 1, s[s_chr]);
    //     }

    //     s_chr++;
    // }

    return 0;
}
