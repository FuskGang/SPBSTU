#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#define MAX_FILE_INPUT 1000
#define MAX_DATA 1000000

int data_insert[MAX_DATA];
int data_quick[MAX_DATA];
int data_merge[MAX_DATA];
int data_merge_help[MAX_DATA];
char date[50];

int get_data(char *);
void get_date(char *);
void insertion_sort(unsigned long long *, unsigned long long *, int *);
void quick_sort(unsigned long long *, unsigned long long *, int, int);
void merge_sort(unsigned long long *, unsigned long long *, int *, int *, int, int);
void print_sorted_data(int *, int *);
void logg(char *, char *);
void write_result(int *, int *, char *);
void write_characteristics(char *, unsigned long long *, unsigned long long *, unsigned long long *);

int main()
{
    char input_file[MAX_FILE_INPUT];
    unsigned long long c = 0, m = 0;
    unsigned long long time_spent = 0;
    int l = 0, r = 0;
    clock_t begin, end;

    get_date(date);

    fgets(input_file, MAX_FILE_INPUT, stdin);
    input_file[strcspn(input_file, "\n")] = '\0';

    int n = get_data(input_file);
    if (n == -1)
    {
        return 1;
    }

    // begin = clock();
    // insertion_sort(&c, &m, &n);
    // end = clock();
    // time_spent = (unsigned long long)(end - begin);
    // write_characteristics("Insertion Sort", &c, &m, &time_spent);
    // write_result(data_merge, &n, "Insertion Sort");

    // r = n - 1;
    // begin = clock();
    // quick_sort(&c, &m, l, r);
    // end = clock();
    // time_spent = (unsigned long long)(end - begin);
    // write_characteristics("Quick Sort", &c, &m, &time_spent);
    // write_result(data_merge, &n, "Quick Sort");

    // begin = clock();
    // merge_sort(&c, &m, data_merge_help, data_merge, 0, n);
    // end = clock();
    // time_spent = (unsigned long long)(end - begin);
    // write_characteristics("Merge Sort", &c, &m, &time_spent);
    // write_result(data_merge, &n, "Merge Sort");

    return 0;
}

void print_sorted_data(int *data, int *n)
{
    for (int i = 0; i < *n; i++)
    {
        printf("%d ", data[i]);
    }
}

int get_data(char *input_file)
{
    FILE *input_stream = NULL;
    
    int temp_elem = 0;
    int count_elem = 0;

    if ((input_stream = fopen(input_file, "r")) == NULL)
    {
        return -1;
    }

    while (fscanf(input_stream, "%d, ", &temp_elem) != EOF)
    {
        data_insert[count_elem] = temp_elem;
        data_quick[count_elem] = temp_elem;
        data_merge[count_elem] = temp_elem;
        data_merge_help[count_elem] = temp_elem;
        count_elem++;
    }

    fclose(input_stream);
    return count_elem;
}

void get_date(char *source)
{
    time_t current_date = time(NULL);
    struct tm *now = localtime(&current_date);

    int min = now->tm_min;
    int hour = now->tm_hour;
    int mday = now->tm_mday;
    int mon = now->tm_mon + 1;
    int year = now->tm_year + 1900;

    if (min < 10)
    {
        source[0] = '0';
        source[1] = (min)+'0';
    }
    else
    {
        source[0] = (min / 10)+'0';
        source[1] = (min % 10)+'0';
    }

    source[2] = '_';

    if (hour < 10)
    {
        source[3] = '0';
        source[4] = (hour)+'0';
    }
    else
    {
        source[3] = (hour / 10)+'0';
        source[4] = (hour % 10)+'0';
    }

    source[5] = '_';

    if (mday < 10)
    {
        source[6] = '0';
        source[7] = (mday)+'0';
    }
    else
    {
        source[6] = (mday / 10)+'0';
        source[7] = (mday % 10)+'0';
    }

    source[8] = '_';

    if (mon < 10)
    {
        source[9] = '0';
        source[10] = (mon)+'0';
    }
    else
    {
        source[9] = (mon / 10)+'0';
        source[10] = (mon % 10)+'0';
    }

    source[11] = '_';
    source[12] = (year / 1000)+'0';
    source[13] = (year / 100 % 10)+'0';
    source[14] = (year / 10 % 10)+'0';
    source[15] = (year % 10)+'0';
    source[16] = '.';
    source[17] = 't';
    source[18] = 'x';
    source[19] = 't';
}

void logg(char *msg, char *sort_name)
{
    char log_file_name[100];
    sprintf(log_file_name, "log_%s", date);

    FILE *input_stream = fopen(log_file_name, "a");

    fprintf(input_stream, "[%s] %s\n", sort_name, msg);
    fclose(input_stream);
}

void write_result(int *data, int *size, char *sort_name)
{
    int n = *size;
    char res_file_name[100];
    sprintf(res_file_name, "result_%s__%s.txt", sort_name, date);

    FILE *input_stream = fopen(res_file_name, "w");

    for (int i = 0; i < n - 1; i++)
    {
        fprintf(input_stream, "%d, ", data[i]);
    }

    fprintf(input_stream, "%d\n", data[n - 1]);
    fclose(input_stream);
}

void write_characteristics(char *name_sort, unsigned long long *c, unsigned long long *m, unsigned long long *time)
{
    char chr_file_name[100];
    sprintf(chr_file_name, "characteristics_%s.txt", date);

    FILE *input_stream = fopen(chr_file_name, "a");


    fprintf(input_stream, "%s: %lld\t%lld\t%lld\n", name_sort, *c, *m, *time);
    fclose(input_stream);

    *c = 0;
    *m = 0;
    *time = 0;
}

void insertion_sort(unsigned long long *c, unsigned long long *m, int *size)
{
    char msg[100];
    int j, temp, n = *size;

    for (int i = 1; i < n; i++)
    {
        sprintf(msg, "На очереди %d элемент", i);
        logg(msg, "Insertion Sort");

        temp = data_insert[i];
        j = i;
        while (j > 0 && temp < data_insert[j - 1])
        {
            sprintf(msg, "Нашли место для вставки %d элемента", j - 1);
            logg(msg, "Insertion Sort");
            data_insert[j] = data_insert[j - 1];
            (*c)++;
            (*m)++;
            j--;
        }

        sprintf(msg, "Ставим на %d место %d элемент", j, i);
        logg(msg, "Insertion Sort");
        data_insert[j] = temp;
        (*m)++;
        (*m)++;
    }
}

void quick_sort(unsigned long long *c, unsigned long long *m, int l, int r)
{
    char msg[50];
    int i = l;
    int j = r;
    int x = data_quick[(l + r) / 2];

    sprintf(msg, "Выбрали опорный элемент он равен -> %d", x);
    logg(msg, "Quick Sort");

    while (i <= j)
    {
        while (data_quick[i] < x)
        {
            (*c)++;
            i++;
        }

        while (data_quick[j] > x)
        {
            (*c)++;
            j--;
        }

        if (i <= j)
        {
            (*m)++;
            int w = data_quick[i];
            data_quick[i] = data_quick[j];
            data_quick[j] = w;
            i++;
            j--;
        }

    }

    logg("Разбили массив на два подмассива", "Quick Sort");

    if (l < j)
    {
        logg("Запуск qsort для левого подмассива", "Quick Sort");
        quick_sort(c, m, l, j);
    }
    if (i < r)
    {
        logg("Запуск qsort для правого подмассива", "Quick Sort");
        quick_sort(c, m, i, r);
    } 
}

void merge_sort(unsigned long long *c, unsigned long long *m, int *in, int *out, int l, int r)
{
    if (r - l < 2)
    {
        logg("Базовый случай: остался только один элемент", "Merge Sort");
        return;
    }
    if (r - l == 2)
    {
        logg("Базовый случай: осталось только два элемента", "Merge Sort");
        if (out[l] > out[l + 1])
        {
            (*c)++;
            (*m)++;
            int temp = out[l];

            out[l] = out[l + 1];
            out[l + 1] = temp;
        }
    }

    int mid = (l + r) / 2;


    merge_sort(c, m, out, in, l, mid);
    logg("Отсортировали первую половину массива", "Merge Sort");
    merge_sort(c, m, out, in, mid, r);
    logg("Отсортировали первую вторую массива", "Merge Sort");

    int i = l;
    int j = mid;
    int idx = l;

    while (idx < r)
    {
        if (j >= r || (i < mid && in[i] < in[j]))
        {
            out[idx] = in[i];

            (*c)++;
            (*m)++;
            i++;
        }
        else
        {
            out[idx] = in[j];

            (*m)++;
            j++;
        }
        idx++;
    }

    logg("'Сливаем два массива в один'", "Merge Sort");
}