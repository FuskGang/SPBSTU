#include <stdio.h>

int main(void)
{
    int n;
    int ans = 0;

    scanf("%d", &n);

    int array[10000] = {0};

    for (int i = 0; i < n; i++)
    {
        scanf("%d", (array + i));
    }

    int cnt_97 = 0;

    for (int i = 0; i < n; i++)
    {
        if (array[i] == 97)
        {
            cnt_97++;
        }
    }

    for (int i = 0; i < n; i++)
    {
        int elem = array[i];

        if (elem == 'a')
        {
            continue;
        }

        int cnt = 1;

        for (int j = i + 1; j < n; j++)
        {
            if (array[j] == elem)
            {
                array[j] = 'a';
                cnt++;
            }
        }

        if (cnt <= 3)
        {
            ans++;
        }
    }

    if (cnt_97 <= 3 && cnt_97 != 0)
    {
        ans++;
    }

    printf("%d", ans);
}