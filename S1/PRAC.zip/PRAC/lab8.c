#include <stdio.h>

int fl = 0;
void show(int pole[24][24], int n)
{
    FILE *output = fopen("output.txt", "a");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (pole[i][j] == 1)
            {
                fprintf(output, "(%d, %d) ", i, j);
            }
        }
    }
    fprintf(output, "\n");
    fclose(output);
}

int CanPut(int pole[24][24], int row, int col, int n)
{
    for (int i = row, j = col; i >= 0 && j >= 0; i--, j--)
    {
        if (pole[i][j] == 1)
        {
            return 0;
        }
    }

    for (int i = row, j = col; i >= 0 && j < n; i--, j++)
    {
        if (pole[i][j] == 1)
        {
            return 0;
        }
    }

    for (int i = row, j = col; i < n && j >= 0; i++, j--)
    {
        if (pole[i][j] == 1)
        {
            return 0;
        }
    }

    for (int i = row, j = col; i < n && j < n; i++, j++)
    {
        if (pole[i][j] == 1)
        {
            return 0;
        }
    }

    return 1;
}

void PlaceBishop(int pole[24][24], int row, int col, int n, int l)
{
    if (l == 0) {
        fl++;
        show(pole, n);
        return;
    }

    if (row >= n)
    {
        return;
    }

    int next_row = row;
    int next_col = col + 1;

    if (next_col >= n)
    {
        next_row++;
        next_col = 0;
    }

    if (CanPut(pole, row, col, n))
    {
        pole[row][col] = 1;
        PlaceBishop(pole, next_row, next_col, n, l - 1);
        pole[row][col] = 0;
    }

    PlaceBishop(pole, next_row, next_col, n, l);
}


int main() 
{
    int n, l, k;

    FILE *f_stream = fopen("input.txt", "r");
    fscanf(f_stream, "%d %d %d", &n, &l, &k);

    int x, y;
    int pole[24][24] = {0};
    for (int i = 0; i < k; i++)
    {
        fscanf(f_stream, "%d %d", &x, &y);
        pole[x][y] = 1;
    }
    fclose(f_stream);

    PlaceBishop(pole, 0, 0, n, l);

    FILE *output = fopen("output.txt", "a");

    if (fl == 0) {
        fprintf(output, "no solutions");
    }
    fclose(output);
}