#include <stdio.h>
#include <string.h>

void answer(char *name)
{
    char name_2[33];
    char sym_res_0 = '\0';
    char sym_res_1 = '\0';
    char prev = '1';
    char in_str[10000];

    strcpy(name_2, name);

    char *name_c = strcat(name, ".c");
    char *name_wc = strcat(name_2, ".wc");

    FILE *input_file = fopen(name_c, "r");
    FILE *output_file = fopen(name_wc, "w");

    int was_string = 0, was_large = 0, was_short = 0, write = 1;
    int glfl = 1;

    while (fgets(in_str, 10000, input_file) != NULL)
    {
        char out_str[10000] = "";

        if (glfl == 1)
        {
            if (in_str[0] == '#')
            {
                fputs(in_str, output_file);
                continue;
            }
            else
            {
                glfl = 0;
            }
        }

        int len = strlen(in_str) - 1;
        int fl_break = 0;

        if (len == 0) {
            fputc(in_str[0], output_file);
            continue;
        }

        int bn = 0, j = 0;

        for (int i = 0; i < (strlen(in_str)); i++)
        {
            char fs = in_str[i];
            char ss = in_str[i + 1];

            if (fs == '"' && was_large == 0 && was_short == 0) 
            {
                if(was_string == 1)
                {
                    was_string = 0;
                }
                else
                {
                    write = 1;
                    was_string = 1;
                }
            }

            if (fs == '/' && was_string == 0 && was_large == 0 && was_short == 0) 
            {
                if (ss == '/' && was_large == 0) {
                    write = 0;
                    was_short = 1;
                }
                if (ss == '*' && was_short == 0) {
                    write = 0;
                    was_large = 1;
                }

            }

            if (fs == '*' && was_string == 0 && was_large == 1 && was_short == 0)
            {
                if (ss == '/') {
                    was_large = 0;
                    write = 1;
                    i++;
                    continue;
                }
            }
            
            if (ss == '\n')
            {
                if (fs == '\\' && was_short == 1) {
                    write = 0;
                    continue;
                }

                if (was_short == 1) {
                    was_short = 0;
                    write = 1;
                    break;
                }
        
                if (was_large == 1) {
                    write = 0;
                }

                if (was_large == 0) {
                    was_short = 0;
                    write = 1;
                    bn = 1;
                }
            }

            if (write == 1)
            {
                out_str[j] = fs;
                j += 1;
            }
        }

        fputs(out_str, output_file);

        if (bn == 1)
        {
            fputc('\n', output_file);
        }
    }

    fclose(output_file);
    fclose(input_file);
}

int main()
{
    FILE *input_main_file = fopen("project.txt", "r");

    int n;

    fscanf(input_main_file, "%d", &n);

    for (int i = 0; i < n; i++)
    {

        char name_file[33];
        fscanf(input_main_file, "%s", name_file);

        int len_f = strlen(name_file);
        name_file[len_f - 1] = 0;
        name_file[len_f - 2] = 0;

        answer(name_file);
    }
    fclose(input_main_file);
}