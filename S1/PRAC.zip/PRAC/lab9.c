#include <stdio.h>
#include <string.h>

void answer(char *name) {
    char name_2[33];
    char sym_res_0 = '\0';
    char sym_res_1 = '\0';
    char prev = '1';
    strcpy(name_2, name);

    char *name_c = strcat(name, ".c");
    char *name_wc = strcat(name_2, ".wc");

    FILE *input_file = fopen(name_c, "r");
    FILE *output_file = fopen(name_wc, "w");

    int was_kov = 0, skip = 0, large_com = 0;

    int was_kom = 0;

    while (1) {
        char sym = fgetc(input_file);
        if (sym == EOF) {
            break;
        }

        sym_res_0 = sym;

        if (sym == '"' && (was_kom == 0 && large_com == 0))
        {
            if (was_kov == 1) {
                was_kov = 0;
            }
            else {
                was_kov = 1;
            }
        }
        else if ((sym == '/' || sym == '*') && was_kov == 0 && was_kom == 0) {
            char nx = fgetc(input_file);

            if (nx == EOF) {
                break;
            }

            if (prev == '*' && sym == '/') {
                large_com = 0;
                prev = '\0';
                sym_res_1 = '\0';
                sym_res_0 = '\0';
            }

            if (nx == '/') {
                if (sym == '/') {
                    if (large_com == 0){
                        was_kom = 1;
                        sym_res_1 = '\0';
                    }
                }
                else if (sym == '*' && large_com == 1)
                {
                    large_com = 0;
                    continue;
                }
            }

            else if (nx == '*') {
                if (sym == '/')
                {
                    large_com = 1;
                    sym_res_1 = '\0';
                }
                else {
                    if (prev != '\0') {
                        sym_res_1 = nx;
                        prev = nx;
                        // printf("here\n");
                    }
                }
            }

            else {
                if (nx == '\n') {
                    was_kom = 0;
                    fputc('\n', output_file);
                    continue;
                }
                sym_res_1 = nx;

            }
        }

        else if (sym == '\\') {
            if (was_kom == 1) {
                skip = 1;
            }
        }

        else if (sym == '\n') {
            if (skip == 1) {
                skip = 0;
            }

            else {
                if (was_kom == 1 && large_com == 0) {
                    sym_res_0 = '\n';
                    sym_res_1 = '\0';
                    was_kom = 0;
                }
            }
        }

        if (was_kom == 0 && large_com == 0) {
            if (sym_res_0 != '\0')
            {
                fputc(sym_res_0, output_file);
            }

            if (sym_res_1 != '\0')
            {
                fputc(sym_res_1, output_file);
            }
            sym_res_1 = '\0';
        }

    }

    fclose(output_file);
    fclose(input_file);
}

int main() {
    FILE *input_main_file = fopen("project.txt", "r");

    int n;

    fscanf(input_main_file, "%d", &n);

    for (int i = 0; i < n; i++) {

        char name_file[33];
        fscanf(input_main_file, "%s", name_file);

        int len_f = strlen(name_file);
        name_file[len_f - 1] = 0;
        name_file[len_f - 2] = 0;

        answer(name_file);
    }
    fclose(input_main_file);
}