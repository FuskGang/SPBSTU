#include <stdio.h>
#include <string.h>
#include <locale.h>


void refresh_arr(int arr[2][32]) {
    for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 32; j++)
        {
            arr[i][j] = 0;
        }
        
    }
}

void update_arr(int arr[2][32]) {
    int size_w1 = 0, size_w2 = 0;
    int min_size = 0;
    int fl = 0;
    int ans[64] = {0};

    for (int i = 0; i < 32; i++)
    {
        if (arr[0][i] == 0) {
            break;
        }
        size_w1++;
    }

    for (int i = 0; i < 32; i++)
    {
        if (arr[1][i] == 0)
        {
            break;
        }
        size_w2++;
    }

    min_size = (size_w1 < size_w2) ? size_w1 : size_w2;
    int offset = min_size;

    for (offset = min_size; offset > 0; offset--)
    {
        for (int off_w1 = size_w1 - offset, off_w2 = 0; off_w1 < size_w1; off_w1++, off_w2++) 
        {
            int w1_code = arr[0][off_w1];
            int w2_code = arr[1][off_w2];

            if (w1_code == w2_code) {
                fl = 1;
            }
            else {
                fl = 0;
                break;
            }

        }


        if (fl == 1) {
            break;
        }
        
    }

    for (int i = 0; i < size_w1; i++)
    {
        ans[i] = arr[0][i];
    }

    for (int i = size_w1, j = offset; j < size_w2; i++, j++)
    {
        ans[i] = arr[1][j];
    }

    for (int i = 0; i < sizeof(ans) / sizeof(*ans); i++)
    {
        printf("%c", ans[i]);
    }

    printf("\n");
}

int main(void)
{
    setlocale(LC_ALL, "utf-8");

    int n;
    scanf("%d", &n);
    getchar();

    for (int i = 0; i < n; i++)
    {

        int code;
        int cnt_word = 0, cnt_letter = 0;
        int words[2][32];
        refresh_arr(words);

        char fw[32];
        char sw[32];

        scanf("%s %s", fw, sw);

        for (int i = 0; i < strlen(fw); i++)
        {
            words[0][i] = fw[i];
        }

        for (int i = 0; i < strlen(sw); i++)
        {
            words[1][i] = sw[i];
        }

        update_arr(words);
    }
}
